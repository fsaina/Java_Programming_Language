package jmbag0036479300.android.fer.hr.calculator;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

/**
 * User notifier activity. Final result or error message from the Calculus activity is displayed
 * here. Depending on the message type the interaction buttons are displayed or not.
 *
 * @author filipsaina
 */
public class DisplayActivity extends AppCompatActivity {

    /**
     * Reference to the confirmation button
     */
    private Button okButton;

    /**
     * Reference to the error message send button
     */
    private Button errorReportButton;

    /**
     * Reference to the message text view on the activity
     */
    private TextView messageTextView;

    /**
     * Reference to the returned intent
     */
    private Intent intent;

    /**
     * Decimal format used for displaying decimal values
     */
    private DecimalFormat fourFormat = new DecimalFormat("#.####");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        intent = getIntent();
        messageTextView = (TextView) findViewById(R.id.error_message_textview);
        okButton = (Button) findViewById(R.id.ok_button);
        errorReportButton = (Button) findViewById(R.id.send_report_button);

        setupScreen();
    }

    /**
     * Method initializes the activity screen properties. All values are obtained from the CalculusActivity.
     */
    private void setupScreen() {
        String message;

        String operation = intent.getStringExtra(getResources().getString(R.string.operation_intent));
        String op1 = intent.getStringExtra(getResources().getString(R.string.number1_intent));
        String op2 = intent.getStringExtra(getResources().getString(R.string.number2_intent));
        String errorMessage = intent.getStringExtra(getResources().getString(R.string.error_message_intent));
        String result = fourFormat.format(intent.getDoubleExtra(getResources().getString(R.string.result_intent), Double.MIN_VALUE));

        if (errorMessage == null) {

            message = String.format(
                    getResources().getString(R.string.message_format),
                    operation.toLowerCase(),
                    result);

            okButton.setVisibility(View.INVISIBLE);
            errorReportButton.setVisibility(View.INVISIBLE);

        } else {
            message = String.format(
                    getResources().getString(R.string.error_message_format),
                    operation.toLowerCase(),
                    op1,
                    op2,
                    errorMessage);
        }

        messageTextView.setText(message);
    }

    /**
     * Method called on ok button press
     *
     * @param view current view reference
     */
    public void okButtonPress(View view) {
        CalculusActivity.KEEPVALUES = false;
        finish();
    }

    /**
     * Method called on send_error button press.
     * Current implementation sends a error message whit the message contained on the displayed message.
     *
     * @param view current view reference
     */
    public void sendErrorReportButtonPress(View view) {
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto", getString(R.string.send_errorreport_email), null));

        intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.send_errorreport_subject));
        intent.putExtra(Intent.EXTRA_TEXT, messageTextView.getText());

        startActivity(Intent.createChooser(intent, getString(R.string.send_errorreport_info_message)));
    }
}
