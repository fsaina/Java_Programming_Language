package jmbag0036479300.android.fer.hr.calculator;

import android.content.Intent;
import android.content.res.TypedArray;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

/**
 * Activity class used for displaying and manipulating basic calculus operations like
 * addition, subtraction, multiplication and division. Supported operation array is located
 * in the strings.xml and the implementation is here.
 *
 * @author filipsaina
 */
public class CalculusActivity extends AppCompatActivity {

    /**
     * Reference to the first operation filed
     */
    private EditText operator1;

    /**
     * Reference to the second operation filed
     */
    private EditText operator2;

    /**
     * Reference to the operation spinner - values are loaded from strings.xml array
     */
    private Spinner operationSpinner;

    /**
     * Flag that indicates weather or not to keep activity values or set them
     * to default on activity start
     */
    public static boolean KEEPVALUES = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculus);

        operator1 = (EditText) findViewById(R.id.edit_text_operation_1);
        operator2 = (EditText) findViewById(R.id.edit_text_operation_2);
        operationSpinner = (Spinner) findViewById(R.id.operations_spinner);
    }


    /**
     * Method called when the "calculate" button is pressed. Method calculates the result value
     * from the input fields and puts them into the enxt intent.
     *
     * @param view current view reference
     */
    public void onCalculatePress(View view) {

        Intent displayIntent = new Intent(CalculusActivity.this, DisplayActivity.class);
        Double result = null;
        double op1;
        double op2;

        try {
            op1 = Double.parseDouble(operator1.getText().toString());
            op2 = Double.parseDouble(operator2.getText().toString());
            result = calculateOperation(op1, op2);

        } catch (Exception e) {
            displayIntent.putExtra(getString(R.string.error_message_intent), e.getLocalizedMessage());
        }

        displayIntent.putExtra(getString(R.string.operation_intent), stringSpinnerSelection());
        displayIntent.putExtra(getString(R.string.number1_intent), operator1.getText().toString());
        displayIntent.putExtra(getString(R.string.number2_intent), operator2.getText().toString());
        displayIntent.putExtra(getString(R.string.result_intent), result);
        startActivity(displayIntent);
    }

    /**
     * Performs operation oven given parameters. Depending on the spinner selected element from the
     * strings.xml array there is a given operation performed. Result of operations is returned.
     *
     * @param op1 First operator in the operation
     * @param op2 Second operator in the operation
     * @return result of the operation
     */
    private double calculateOperation(double op1, double op2) {
        String operation = stringSpinnerSelection();

        switch (operation.toLowerCase()) {
            case "zbrajanje": {
                return op1 + op2;
            }

            case "oduzimanje": {
                return op1 - op2;
            }

            case "mnozenje": {
                return op1 * op2;
            }

            case "dijeljenje": {
                return op1 / op2;
            }
        }

        throw new IllegalStateException(getString(R.string.error_message_unsuported_operation));
    }

    /**
     * Returns string value for the spinner element selection
     *
     * @return String value of the current selected element in the spinner
     */
    private String stringSpinnerSelection() {
        TypedArray operationsArray = getResources().obtainTypedArray(R.array.operations_array);
        return operationsArray.getString(operationSpinner.getSelectedItemPosition());
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!KEEPVALUES) {
            KEEPVALUES = true;

            //reset activity to initial state
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }

    }
}
